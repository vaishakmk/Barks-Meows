<?php

$server = "localhost";
$username = "root";
$password = "";
$dbname = "userdb";

$conn = mysqli_connect($server,$username,$password,$dbname);